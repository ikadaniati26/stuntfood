<?php $__env->startSection('content'); ?>
    <div class="content-wrapper">
        <div class="container-xxl flex-grow-1 container-p-y">
            <div class="row">
                <div class="col">
                    <div class="card mb-4 shadow">
                        <div class="me-3 px-5 mt-5 mb-5">
                            <div>
                                <h3>Tabel Sub Menu</h3>
                                <p>berdasarkan paket menu yang direkomendasikan diatas, maka disarankan memberikan makanan
                                    lengkap dalam satu piring sebanyak 3x dalam sehari, dengan berat yang sudah
                                    direkomendasikan berikut ini:
                            </div>

                            <div class="table-responsive text-nowrap px-5 mt-2">
                                <table class="table table-striped mb-5">
                                    <thead>
                                        <tr>
                                            <th scope="col">Paket</th>
                                            <th scope="col">Waktu Makan</th>
                                            <th scope="col">Nama Makanan</th>
                                            <th scope="col">Jenis Makanan</th>
                                            <th scope="col">Berat</th>
                                            <th scope="col">Protein</th>
                                            <th scope="col">Karbohidrat</th>
                                            <th scope="col">Lemak</th>
                                            <th scope="col">Energi</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <?php $__currentLoopData = $joindata; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <?php if($index % 4 == 0): ?>
                                                <tr>
                                                    <td rowspan="4"><?php echo e($item->paket); ?></td>
                                                    <td rowspan="4"><?php echo e($item->waktu_makan); ?></td>
                                                    <td><?php echo e($item->nama_makanan); ?></td>
                                                    <td><?php echo e($item->jenis_makanan); ?></td>
                                                    <td><?php echo e(number_format($Berat[$index], 2, '.', '')); ?></td>
                                                    <td><?php echo e(number_format($Protein[$index], 2, '.', '')); ?></td>
                                                    <td><?php echo e(number_format($Karbo[$index], 2, '.', '')); ?></td>
                                                    <td><?php echo e(number_format($Lemak[$index], 2, '.', '')); ?></td>
                                                    <td><?php echo e(number_format($Energi[$index], 2, '.', '')); ?></td>
                                                </tr>
                                            <?php else: ?>
                                                <tr>
                                                    <td><?php echo e($item->nama_makanan); ?></td>
                                                    <td><?php echo e($item->jenis_makanan); ?></td>
                                                    <td><?php echo e(number_format($Berat[$index], 2, '.', '')); ?></td>
                                                    <td><?php echo e(number_format($Protein[$index], 2, '.', '')); ?></td>
                                                    <td><?php echo e(number_format($Karbo[$index], 2, '.', '')); ?></td>
                                                    <td><?php echo e(number_format($Lemak[$index], 2, '.', '')); ?></td>
                                                    <td><?php echo e(number_format($Energi[$index], 2, '.', '')); ?></td>
                                                </tr>
                                            <?php endif; ?>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div>

                    <div class="card mb-4  shadow">
                        <div class="me-3 px-5 mt-5">
                            <div>
                                <h3>Tabel Selingan</h3>
                                <p>berdasarkan paket menu yang direkomendasikan diatas, maka disarankan memberikan makanan
                                    selingan berikut ini:
                            </div>
                            <div class="table-responsive text-nowrap px-5 mt-2">
                                <table class="table table-striped ">
                                    <thead>
                                        <tr>
                                            <th scope="col">Paket</th>
                                            <th scope="col">Waktu Makan</th>
                                            <th scope="col">Nama Selingan</th>
                                            <th scope="col">Berat</th>
                                            <th scope="col">Protein</th>
                                            <th scope="col">karbohidrat</th>
                                            <th scope="col">lemak</th>
                                            <th scope="col">energi</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                         <?php $no=1; ?>
                                        <?php $__currentLoopData = $dataSelingan; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <?php if($index % 4 == 0): ?>
                                                <tr>
                                                    <td rowspan="4"><?php echo e($item->paket); ?></td>
                                                    <td><?php echo e($item->waktu_makan); ?></td>
                                                    <td><?php echo e($item->menu); ?></td>
                                                    <td><?php echo e(number_format($BeratSelingan[$index], 2, '.', '')); ?></td>
                                                    <td><?php echo e(number_format($ProteinSelingan[$index], 2, '.', '')); ?></td>
                                                    <td><?php echo e(number_format($KarbohidratSelingan[$index], 2, '.', '')); ?></td>
                                                    <td><?php echo e(number_format($LemakSelingan[$index], 2, '.', '')); ?></td>
                                                    <td><?php echo e(number_format($EnergiSelingan[$index], 2, '.', '')); ?></td>
                                                </tr>
                                                <?php else: ?>
                                                <tr>
                                                    <td><?php echo e($item->waktu_makan); ?></td>
                                                    <td><?php echo e($item->menu); ?></td>
                                                    <td><?php echo e(number_format($BeratSelingan[$index], 2, '.', '')); ?></td>
                                                    <td><?php echo e(number_format($ProteinSelingan[$index], 2, '.', '')); ?></td>
                                                    <td><?php echo e(number_format($KarbohidratSelingan[$index], 2, '.', '')); ?></td>
                                                    <td><?php echo e(number_format($LemakSelingan[$index], 2, '.', '')); ?></td>
                                                    <td><?php echo e(number_format($EnergiSelingan[$index], 2, '.', '')); ?></td>
                                                </tr>
                                            <?php endif; ?>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?> 
                                     

                                     
                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('website.main.index', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\stuntfood\stuntfood\resources\views/website/user/submenu.blade.php ENDPATH**/ ?>