<?php $__env->startSection('content'); ?>
  <div class="content-wrapper">
    <div class="container-xxl flex-grow-1 container-p-y">
      
      <?php if(session("success")): ?>
        <div class="alert alert-success">
          <?php echo e(session("success")); ?>

        </div>
      <?php endif; ?>

      <div class="card">
        <h5 class="card-header mb-0">#Data Paket Menu Makanan</h5>
      
        <div class="table-responsive text-nowrap">
          <a href="<?php echo e(url('created')); ?>">
              <button id="addForm" type="button" class="btn btn-primary  mt-4 mx-4" style="background-color: blue">+tambah data</button>
          </a>
          <table class="table">
            <thead>
              <tr>
                <th>Nomor</th>
                <th>Paket</th>
                <th>Waktu makan</th>
                <th>Menu</th>
                <th>aksi</th>
              </tr>
            </thead>
            <tbody class="table-border-bottom-1">
              <?php
                   $no=1;
              ?>
                <?php $__currentLoopData = $query; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                  <td><?php echo e($no++); ?></td>
                  <td><?php echo e($item->paket); ?></td>
                  <td><?php echo e($item->waktu_makan); ?></td>
                  <td><?php echo e($item->menu); ?></td>
                  <?php if($index % 5 == 0): ?>
                  <td rowspan="5">
                    <form method="POST" action="<?php echo e(route('hapus', ['id'=>$no])); ?>">
                      <?php echo csrf_field(); ?>
                      <?php echo method_field('DELETE'); ?>
                      <a href="<?php echo e(url('showadmin', ['paket' => $item->paket])); ?>" class="btn btn-info btn-sm">
                        <i class="fa-solid fa-eye"></i>
                      </a>
                  
                      <a class="btn btn-warning btn-sm" title="Edit"
                          href="<?php echo e(route('edit', ['paket'=>$item->paket])); ?>">
                          <i class="fa-solid fa-pencil"></i>
                      </a>
                      &nbsp;
                      <button type="submit" class="btn btn-danger btn-sm"
                          title="Hapus Pegawai"
                          onclick="return confirm('Anda Yakin Data akan diHapus?')">
                          <i class="fa-solid fa-trash"></i>
                      </button>
                    </form>
                  </td>
                  <?php endif; ?>
                </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
          </table>
      

        </div>
      </div>
    </div>
  </div>


  <!-- Tautkan Font Awesome CSS -->
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css">
<?php $__env->stopSection(); ?>

<?php echo $__env->make('website.main.index', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\stuntfood\stuntfood\resources\views/website/admin/dataMakananAdmin.blade.php ENDPATH**/ ?>